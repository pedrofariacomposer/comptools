# CompTools
Tools for Assisting in Composing and Analyzing Music
